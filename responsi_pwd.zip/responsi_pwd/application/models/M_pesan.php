<?php
class M_pesan extends CI_Model
{
    public function index()
    {
        date_default_timezone_set('Asia/Jakarta');
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $isi = $this->input->post('isi');
        
        $pesan = array (
            'nama' => $nama,
            'email' => $email,
            'isi' => $isi,
            'tgl_pesan' => date('Y-m-d H:i:s'),
        );
        $this->db->insert('tb_pesan', $pesan);
    }

    public function tampil_data()
    {
        $result = $this->db->get('tb_pesan');
        if($result->num_rows() >0)
        {
            return $result->result();
        }
        else
        {
            return false;
        }
    }

    public function detail_pesan($id)
    {
        $result = $this->db->where('id', $id)->get('tb_pesan');
        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }
}
