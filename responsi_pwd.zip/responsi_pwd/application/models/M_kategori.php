<?php
class M_kategori extends CI_Model
{
    public function tampil_data()
    {
        return $this->db->get('kategori');
    }
    public function tambah_kategori($data, $table)
    {
        $this->db->insert($table, $data);
    }
    public function hapus_kategori($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    // NAVBAR --------------------------------------------
    // REZA ----------------------------------------------
    public function data_bergo()
    {
        return $this->db->get_where("tb_barang", array('kategori' => 'Tsamira Bergo'));
    }
    public function data_segi_empat()
    {
        return $this->db->get_where("tb_barang", array('kategori' => 'Shalina Square'));
    }
    public function data_pashmina()
    {
        return $this->db->get_where("tb_barang", array('kategori' => 'Shaquilla Pashmina'));
    }
}
