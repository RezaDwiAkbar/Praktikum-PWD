<?php

class Authen extends CI_Controller
{

    public function index()
    {
        $this->load->view('templates/auth_header');
        $this->load->view('authen/login');
        $this->load->view('templates/auth_footer');
    }

    public function registrasi()
    {
        $this->load->view('templates/auth_header');
        $this->load->view('authen/registrasi');
        $this->load->view('templates/auth_footer');
    }
}
