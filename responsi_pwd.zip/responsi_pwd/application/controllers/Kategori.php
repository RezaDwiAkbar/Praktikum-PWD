<?php
class Kategori extends CI_Controller
{
    public function hijab_bergo()
    {
        $data['judul'] = 'Hijab Bergo';
        $data['barang'] = $this->m_kategori->data_bergo()->result();
        $this->load->view('templates/header');

        $this->load->view('user/categori', $data);
        $this->load->view('templates/footer');
    }
    public function Hijab_Segi_Empat()
    {
        $data['judul'] = 'Hijab Segi Empat';
        $data['barang'] = $this->m_kategori->data_segi_empat()->result();
        $this->load->view('templates/header');

        $this->load->view('user/categori', $data);
        $this->load->view('templates/footer');
    }
    public function Shaquilla_Pashmina()
    {
        $data['judul'] = 'Shaquilla Pashmina';
        $data['barang'] = $this->m_kategori->data_pashmina()->result();
        $this->load->view('templates/header');
        $this->load->view('user/categori', $data);
        $this->load->view('templates/footer');
    }
}
