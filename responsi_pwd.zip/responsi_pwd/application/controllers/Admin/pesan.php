<?php
class Pesan extends CI_Controller
{
    public function index()
    {
        $data['pesan'] = $this->m_pesan->tampil_data();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/pesan', $data);
        $this->load->view('templates_admin/footer');
    }

    public function detail_pesan($id)
    {
        $data['pesan'] = $this->m_pesan->detail_pesan($id);
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/detail_pesan', $data);
        $this->load->view('templates_admin/footer');
    }
}
