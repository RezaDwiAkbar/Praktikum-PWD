<?php

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('role_id') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Anda Belum Login!</div>');
            redirect('auth/login');
        }
    }
    // BARANG------------------------------------------------------------------------------------------------
    public function index()
    {
        $data = $this->m_data->ambil_data($this->session->userdata['username']);
        $data = array(
            'username' => $data->username,
        );
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/dashboard', $data);
        $this->load->view('templates_admin/footer');
    }

    public function data_barang()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $data['barang'] = $this->m_data->tampil_data()->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/data_barang', $data);
        $this->load->view('templates_admin/footer');
    }

    public function search()
    {
        $keyword = $this->input->post('keyword');
        $data['barang'] = $this->m_data->get_keyword($keyword);
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/data_barang', $data);
        $this->load->view('templates_admin/footer');
    }

    public function edit_data($id)
    {
        $where = array('id_brg' => $id);
        $data['barang'] = $this->m_data->edit_data($where, 'tb_barang')->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/edit_data', $data);
        $this->load->view('templates_admin/footer');
    }

    public function update_data()
    {
        $id = $this->input->post('id_brg');
        $nama = $this->input->post('nama');
        $keterangan = $this->input->post('keterangan');
        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $data = array(
            'nama'  => $nama,
            'keterangan' => $keterangan,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
        );
        $where = array(
            'id_brg' => $id
        );

        $this->m_data->update_data($where, $data, 'tb_barang');
        redirect('admin/dashboard/data_barang');
    }

    public function hapus_data($id)
    {
        $where = array('id_brg' => $id);
        $this->m_data->hapus_data($where, 'tb_barang');
        redirect('admin/dashboard/data_barang');
    }

    public function lihat_barang($id)
    {
        $data['barang'] = $this->m_data->detail_barang($id);
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/lihat_barang', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambah_aksi()
    {
        $nama = $this->input->post('nama');
        $keterangan = $this->input->post('keterangan');
        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

        $namaFile = $_FILES['gambar']['name'];
        $ukuranFile = $_FILES['gambar']['size'];
        $error = $_FILES['gambar']['error'];
        $tmpName = $_FILES['gambar']['tmp_name'];
        // cek apakah upload atau tidak
        if ($error === 4) {
            echo "<script>
                    alert('pilih gambar terlebih dahulu!');
                    </script>";
            return false;
        }
        // upload gambar atau bukan
        $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
        $ekstensiGambar = explode('.', $namaFile);
        $ekstensiGambar = strtolower(end($ekstensiGambar));
        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
            echo "<script>
                    alert('Yang anda upload bukan gambar');
                    </script>";
            return false;
        }
        // ukuran gambar
        if ($ukuranFile > 1000000) {
            echo "<script>
                    alert('Ukuran gambar terlalu besar');
                    </script>";
            return false;
        }

        //lolos pengecekan
        //nama baru
        $namaFileBaru = uniqid();
        $namaFileBaru .= ".";
        $namaFileBaru .= $ekstensiGambar;
        move_uploaded_file($tmpName, 'assets/img/gambar/' . $namaFileBaru);

        $data = array(
            'nama'  => $nama,
            'keterangan' => $keterangan,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
            'gambar' => $namaFileBaru
        );

        $this->m_data->tambah_barang($data, 'tb_barang');
        redirect('admin/dashboard/data_barang');
    }

    // Kategori------------------------------------------------------------------------------------------------
    public function kategori()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/kategori', $data);
        $this->load->view('templates_admin/footer');
    }
    public function tambah_kategori()
    {
        $kategori = $this->input->post('kategori');
        $data = array(
            'kategori'  => $kategori,
        );

        $this->m_kategori->tambah_kategori($data, 'kategori');
        redirect('admin/dashboard/kategori');
    }
    public function hapus_kategori($id)
    {
        $where = array('id' => $id);
        $this->m_kategori->hapus_kategori($where, 'kategori');
        redirect('admin/dashboard/kategori');
    }

    public function hapus_pesan($id)
    {
        $where = array('id' => $id);
        $this->m_data->hapus_data($where, 'tb_pesan');
        redirect('admin/pesan');
    }

    public function xml()
    {
        $this->load->view('admin/mhs_xml');
    }
    public function json()
    {
        $this->load->view('admin/mhs_json');
    }
    public function pdf()
    {
        $this->load->view('admin/lap_mhs');
    }

}
