<?php
class pengunjung extends CI_Controller
{
    public function index()
    {
        $data['pesan'] = $this->m_pesan->tampil_data();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/pengunjung');
        $this->load->view('templates_admin/footer');
    }
}
