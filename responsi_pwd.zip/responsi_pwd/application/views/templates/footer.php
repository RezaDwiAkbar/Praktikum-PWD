  <!-- my css-->
  <link href="<?= base_url('/assets'); ?>/css/footer.css" rel="stylesheet">

  <!-- footer awal -->
  <div class="footer">
      <div class="container">
          <div class="row">
              <div class="col-lg">
                  <strong>Information</strong><br>
                  <ul class="infor">
                      <li><a href="<?= base_url('dashboard/aboutus'); ?>" class="text-footer">About Us</a></li>
                      <li><a href="<?= base_url('dashboard/testimoni'); ?>" class="text-footer">Testimoni</a></li>
                  </ul>
              </div>
              <div class="col-lg">
                  <strong>Help & Support</strong><br>
                  <ul class="infor">
                      <li><a href="<?= base_url('dashboard/faq'); ?>" class="text-footer">FAQ</a></li>
                      <li><a href="<?= base_url('dashboard/kontak'); ?>" class="text-footer">Contact</a></li>
                  </ul>
              </div>
              <div class="col-lg">
                  <strong>Hubungi Kami</strong><br>
                  <a href="https://api.whatsapp.com/send?phone=6281369087018&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A" class="text-footer"><i class="fab fa-whatsapp mr-2"></i>+62 813-6908-7018 (Erliyana Alawiyah)</a><br>

                  <a href="https://api.whatsapp.com/send?phone=6282326471647&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A" class="text-footer"><i class="fab  fa-whatsapp mr-2"></i>+62 823-2647-1647 (Shabrina Anisa)</a><br>

                  <a href="https://www.instagram.com/sha.yeena/" class="text-footer"><i class="fab fa-instagram mr-2"></i>@sha.yeena</a>
              </div>
          </div>
      </div>

  </div>
  <!-- footer akhir -->
  <!-- Bootstrap core JavaScript-->
  <script src="<?= base_url('assets'); ?>/vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets'); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= base_url('assets'); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?= base_url('assets'); ?>/js/sb-admin-2.min.js"></script>

  </body>

  </html>