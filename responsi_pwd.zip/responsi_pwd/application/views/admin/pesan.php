<div class="container-fluid">
    <div class="alert alert-dark" role="alert">
        <i class="fas fa-tachometer-alt mr-2"></i>Pesan
    </div>
    <table class="table table-bordered table-hover table-striped">
        <tr>
            <th>ID Pesan</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Tanggal Pesan</th>
            <th>Isi</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($pesan as $psn) : ?>
            <tr>
                <td><?php echo $psn->id ?></td>
                <td><?php echo $psn->nama ?></td>
                <td><?php echo $psn->email ?></td>
                <td><?php echo $psn->tgl_pesan ?></td>
                <td>
                    <p class="card-text" style="text-align:justify;"><?php echo substr($psn->isi, 0, 40) ?></p>
                </td>
                <td>
                    <?php echo anchor('admin/pesan/detail_pesan/' . $psn->id, '<div class="btn btn-success btn-sm">
                     <i class="fas fa-search-plus"></i></div>') ?>
                    <?php echo anchor('admin/dashboard/hapus_pesan/' . $psn->id, '<div class="btn btn-danger btn-sm">
                    <i class="fa fa-trash"></i></div>') ?>
                </td>
            </tr>

        <?php endforeach; ?>
    </table>
</div>