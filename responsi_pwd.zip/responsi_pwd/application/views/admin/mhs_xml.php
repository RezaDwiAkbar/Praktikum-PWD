<?php
include "koneksi.php";
header('Content-Type: text/xml');
$query = "SELECT * FROM tb_barang";
$hasil = mysqli_query($con, $query);
$jumField = mysqli_num_fields($hasil);

echo "<?xml version='1.0'?>";
echo "<data>";
while ($data = mysqli_fetch_array($hasil)) {
    echo "<tb_barang>";
    echo "<id_brg>", $data['id_brg'], "</id_brg>";
    echo "<nama>", $data['nama'], "</nama>";
    echo "<keterangan>", $data['keterangan'], "</keterangan>";
    echo "<kategori>", $data['kategori'], "</kategori>";
    echo "<harga>", $data['harga'], "</harga>";
    echo "</tb_barang>";
}
echo "</data>";