<div class="container-fluid">
    <?php foreach ($pesan as $psn) : ?>
        <div class="card">
            <h5 class="card-header">
                Pesan
            </h5>
            <div class="card-body" style="color: black;">
                <table>
                    <tr>
                        <td style="padding-bottom: 5px; width:30%;padding-right:10px "><label>Nama Pengirim</label></td>
                        <td style="width:5%;"> :</td>
                        <td style="width:66%;"><?php echo $psn->nama ?></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 5px;"><label>Email Pengirim</label></td>
                        <td> :</td>
                        <td><?php echo $psn->email ?></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom: 5px;"><label>Tanggal</label></td>
                        <td> :</td>
                        <td><?php echo $psn->tgl_pesan ?></td>
                    </tr>
                </table>
                <div class="card-body">
                    <p class="card-text"><?php echo $psn->isi ?></p>
                </div>
                <br><br>
                <?php echo anchor('Admin/pesan/index', '<div class="btn btn-sm btn-danger">Kembali</div>') ?>
            </div>
        <?php endforeach; ?>

        </div>