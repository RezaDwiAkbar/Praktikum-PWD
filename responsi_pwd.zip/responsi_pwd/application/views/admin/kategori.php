<div class="container-fluid">
    <div class="alert alert-dark" role="alert">
        <i class="fas fa-tachometer-alt mr-2"></i>Kategori
    </div>
    <button class="btn btn-sm btn-dark mb-3" data-toggle="modal" data-target="#tambah_data"><i class="fas fa-plus fa-sm"></i> Tambah Barang</button>

    <table class="table table-bordered">
        <tr>
            <th>NO.</th>
            <th>Nama Kategori</th>
            <th style="width: 150px;">AKSI</th>
        </tr>
        <?php
        $no = 1;
        foreach ($kategori as $ktgori) : ?>
            <tr>
                <td style="width: 10px;"><?= $no++ ?>.</td>
                <td><?= $ktgori->kategori ?></td>
                <td>
                    <?php echo anchor('admin/dashboard/hapus_kategori/' . $ktgori->id, '<div class="btn btn-danger btn-sm">
                    <i class="fa fa-trash"></i></div>') ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>


<!-- Modal -->
<div class="modal fade" id="tambah_data" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">TAMBAH DATA</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('admin/dashboard/tambah_kategori') ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nama">Nama Kategori</label>
                        <input type="text" name="kategori" class="form-control">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
        </div>
    </div>
</div>