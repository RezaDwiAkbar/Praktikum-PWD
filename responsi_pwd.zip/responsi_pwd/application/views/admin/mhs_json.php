<?php
include "koneksi.php";

$sql="select * from tb_barang order by id_brg";
$tampil = mysqli_query($con,$sql); if (mysqli_num_rows($tampil) > 0) {
$no=1;
$response = array();
$response["data"] = array();
while ($r = mysqli_fetch_array($tampil)) {
$h['id_brg'] = $r['id_brg'];
$h['nama'] = $r['nama'];
$h['keterangan'] = $r['keterangan'];
$h['kategori'] = $r['kategori'];
$h['harga'] = $r['harga'];
array_push($response["data"], $h);
}
echo json_encode($response);
}
else {
$response["message"]="tidak ada data"; echo json_encode($response);
}