<div class="container-fluid">
    <h3><i class="fas fa-edit"></i>Edit Data</h3>

    <?php foreach($barang as $brg):?>
    <form method="post" action="<?= base_url('admin/dashboard/update_data')?>">
        <div class="for-group">
            <label>Nama Barang</label>
            <input type="text" name="nama" class="form-control" value="<?php echo $brg->nama ?>">
        </div>
        <div class="for-group">
            <label>Keterangan</label>
            <input type="hidden" name="id_brg" class="form-control" value="<?php echo $brg->id_brg ?>">
            <input type="text" name="keterangan" class="form-control" value="<?php echo $brg->keterangan ?>">
        </div>
        <div class="for-group">
            <label>Kategori</label>
            <input type="text" name="kategori" class="form-control" value="<?php echo $brg->kategori ?>">
        </div>
        <!-- <div class="form-group">
            <label for="keterangan">Kategori</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Pilihan</label>
                </div>
                <select class="custom-select" id="inputGroupSelect01" value="<?php echo $brg->kategori ?>">
                    <option selected></option>
                    <option value="Segi Empat">Segi Empat</option>
                    <option value="Pashmina">Pashmina</option>
                    <option value="Instan">Instan</option>
                    <option value="Segi Tiga">Segi Tiga</option>
                </select>
            </div>
        </div> -->
            <div class="for-group">
                <label>Harga</label>
                <input type="text" name="harga" class="form-control" value="<?php echo $brg->harga ?>">
            </div>
            <div class="for-group">
                <label>Stok</label>
                <input type="text" name="stok" class="form-control" value="<?php echo $brg->stok ?>">
            </div>
            <button type="submit" class="btn btn-primary btn-sm mt-5">Simpan</button>
    </form>
    <?php endforeach;?>

</div>