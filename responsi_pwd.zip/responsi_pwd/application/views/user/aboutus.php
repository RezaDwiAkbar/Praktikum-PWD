<link href="<?= base_url('/assets'); ?>/css/aboutus.css" rel="stylesheet">

<!-- jumbotron -->
<div class="jumbotron jumbotron-fluid" style="	background-image: url(<?= base_url('/assets'); ?>/img/aboutus/brand.jpg);">
    <div class="container">
        <section class="logo">


            <div class="row justify-content-center">
                <div class="col-lg-6 justify-content-center d-flex">

                    <figure class="figure">
                        <img src="<?= base_url('/assets'); ?>/img//aboutus/wow.jpg" alt="test 2" class="figure-img img-fluid rounded-circle">
                        <figcaption class="figure-caption">
                        </figcaption>
                    </figure>
                </div>
            </div>
        </section>
        <h1 class="display-4"><span>" You Can Be Pretty Like You "</span><br>
            Shayeena Hijab
        </h1>
    </div>
</div>
<!-- akhir jumbotron -->

<!-- container -->
<div class="container">
    <!-- panel -->
    <div class="row justify-content-center">
        <div class="col-7 info-panel">
            <div class="row">
                <div class="col-lg">
                    <img src="<?= base_url('/assets'); ?>/img//aboutus/jam.jpg" alt="Employee" class="float-left">
                    <h4>24 Hours</h4>
                    <p>Siap melayani pemesanan dalam 24 Jam</p>
                </div>
                <div class="col-lg">
                    <img src="<?= base_url('/assets'); ?>/img//aboutus/cod1.jpg" alt="Employee" class="float-left">
                    <h4>Delivery</h4>
                    <p>Jasa pengiriman yang digunakan adalah JNE</p>
                </div>
                <div class="col-lg">
                    <img src="<?= base_url('/assets'); ?>/img//aboutus/telepon.jpg" alt="Employee" class="float-left">
                    <h4>Fast Respons</h4>
                    <p>cepat dalam merespon jikalau ada pertanyaan</p>
                </div>

            </div>
        </div>
    </div>
    <!-- akhir panel -->
</div>
<!-- Deskripsi -->
<section class=" admin">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h5>Shayeena Hijab menyediakan berbagai jenis hijab kekinian dengan kualitas terbaik.
                Pilihan warna dan model yang bervariasi membuat Harimu semakin indah.</h5>
            <h5 style="	font-weight: bold;">"Our brand logo is made of rose gold acrylicis"</h5>
        </div>
    </div>
    <br><br><br>
    <div class="row justify-content-center">
        <div class="col-lg-6 justify-content-center d-flex">
            <figure class="figure">
                <a href="https://api.whatsapp.com/send?phone=6282326471647&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A" style="text-decoration:none"><img src="<?= base_url('/assets'); ?>/img//aboutus/profile2.jpg" class="figure-img img-fluid rounded-circle " alt="test 2">
                    <figcaption class="figure-caption">
                        <h5>Sabrina</h5>
                        <p>Admin1</p>
                    </figcaption>
                </a>
            </figure>
            <figure class="figure">
                <a href="https://api.whatsapp.com/send?phone=6281369087018&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A" style="text-decoration:none"><img src="<?= base_url('/assets'); ?>/img//aboutus/profile3.jpg" class="figure-img img-fluid rounded-circle" alt="test 2">
                    <figcaption class="figure-caption">

                        <h5>Erliyana</h5>

                        <p>Admin2</p>
                    </figcaption>
                </a>
            </figure>


        </div>
    </div>
</section>
<!-- akhir deskripsi -->