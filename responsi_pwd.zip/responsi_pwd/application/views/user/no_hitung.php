<div class="text-center text-white" style="background-color: black; padding:10px;" role="alert">
    <hr style="	border: 0;
	height: 1px;
	background-image: linear-gradient(
		to right,
		rgba(255, 255, 255, 0),
		rgba(255, 255, 255, 0.75),
		rgba(255, 255, 255, 0)
	);">
    <p>Jumlah Pengunjung : <?php $count_my_page = ("Jumlah_Pengunjung.txt");
                            $hits = file($count_my_page);
                            $fp = fopen($count_my_page, "w");
                            fputs($fp, "$hits[0]");
                            fclose($fp);
                            echo $hits[0];     ?></p>
</div>